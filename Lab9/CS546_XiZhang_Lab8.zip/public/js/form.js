(function () {
    "use strict";
    let textManiMethods = {
        manipulate: function (text_area) {
            if (text_area == null || text_area == "") throw "Must provide a text area";
            if (typeof (text_area) != "string") throw "Input must be string";
            text_area = text_area.replace(/[\ |\~|\`|\!|\@|\#|\$|\%|\^|\&|\*|\(|\)|\-|\_|\+|\=|\||\\|\[|\]|\{|\}|\;|\:|\"|\'|\,|\<|\.|\>|\/|\?]/g, "");
            text_area = text_area.toLowerCase();
            let a = text_area.split("").reverse().join("");
            if (a == text_area) {
                return "is-palindrome";
            }
            return "not-palindrome";
        }
    }

    var staticForm = document.getElementById("static-form");

    if (staticForm) {
        var text_areaElement = document.getElementById("text_area");

        var errorContainer = document.getElementById("error-container");
        var errorTextElement = errorContainer.getElementsByClassName("text-goes-here")[0];

        var resultContainer = document.getElementById("result-container");
        var resultTextElement = resultContainer.getElementsByClassName("text-goes-here")[0];


        const isPalindrome = document.getElementsByClassName("is-palindrome")[0];
        const notPalindrome = document.getElementsByClassName("not-palindrome")[0];


        staticForm.addEventListener("submit", function (event) {
            event.preventDefault();

            try {
                errorContainer.classList.add("hidden");
                resultContainer.classList.add("hidden");

                var text_areaValue = text_areaElement.value;

                var result = textManiMethods["manipulate"](text_areaValue);

                resultTextElement.textContent = result;
                resultContainer.classList.remove("hidden");


                let entry = document.createElement('li');
                entry.appendChild(document.createTextNode(text_areaValue));

                let processed = text_areaValue.toLowerCase().match(/[a-z0-9]/g).join("");

                if (processed === processed.split("").reverse().join("")) {
                    isPalindrome.appendChild(entry);
                }
                else {
                    //entry.style.backgroundColor = "red";
                    notPalindrome.appendChild(entry);
                }





            } catch (e) {
                var message = typeof e === "string" ? e : e.message;
                errorTextElement.textContent = e;
                errorContainer.classList.remove("hidden");
            }
        })
    }
})();






// const isPalindrome = document.getElementsByClassName("is-palindrome")[0];
//         const notPalindrome = document.getElementsByClassName("not-palindrome")[0];
//         // We can take advantage of functional scoping; our event listener has access to its outer functional scope
//         // This means that these variables are accessible in our callback
//         testerForm.addEventListener("submit", (event) => {
//             event.preventDefault();

//             try {
//                 // hide containers by default
//                 errorTextElement.textContent = null;

//                 // Values come from inputs as strings, no matter what :(
//                 let inputString = inputStringElement.value;

//                 let entry = document.createElement('li');
//                 entry.appendChild(document.createTextNode(inputString));

//                 processed = inputString.toLowerCase().match(/[a-z0-9]/g).join("");

//                 if (processed === processed.split("").reverse().join("")) {
//                     isPalindrome.appendChild(entry);
//                 }
//                 else {
//                     notPalindrome.appendChild(entry);
//                 }