let exportedMethods = {
    manipulate(text_area) {
        if (text_area == null || text_area == "") throw "Error : You did't submit a text";
        if (typeof(text_area) != "string" ) throw "Error : Data type isn't String";
        text_area = text_area.replace(/[\ |\~|\`|\!|\@|\#|\$|\%|\^|\&|\*|\(|\)|\-|\_|\+|\=|\||\\|\[|\]|\{|\}|\;|\:|\"|\'|\,|\<|\.|\>|\/|\?]/g, "");
        text_area = text_area.toLowerCase();
        let a = text_area.split("").reverse().join("");
        if(a == text_area) {
            return "is-palindrome";
        }else{
            return "not-palindrome";
        }
    }
// manipulate(text_area, insert_string, insert_times, num_char) {
//     if (text_area == null || text_area == "") throw "Must provide a text area";
//     if (insert_string == null || insert_string == "") throw "Must provide a string to be inserted";
//     if (typeof insert_times !== "number" || isNaN(insert_times)) throw "Must provide a number which is the insertion times";
//     if (typeof num_char !== "number" || isNaN(num_char)) throw "Must provide a number which is the number of characters between insertion";

//     let result = text_area;
//     String.prototype.splice = function (idx, rem, str) {
//         return this.slice(0, idx) + str + this.slice(idx + Math.abs(rem));
//     };
//     for (let i = 1; i <= insert_times; i++) {
//         let start = num_char * i + insert_string.length * (i - 1);
//         result = result.splice(start, 0, insert_string);
//     }
//     return result;
}

module.exports = exportedMethods;

