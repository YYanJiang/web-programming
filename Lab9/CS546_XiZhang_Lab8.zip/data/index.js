const isPalindrome = require('./isPalindrome');

module.exports = {
    isPalindrome:isPalindrome
};
