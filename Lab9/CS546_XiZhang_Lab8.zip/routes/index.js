const isPalindromeRoutes = require("./isPalindrome");

const constructorMethod = (app) => {
    app.use("/isPalindrome", isPalindromeRoutes);

    app.use("*", (req, res) => {
        res.redirect("/isPalindrome/clientform");
    })
};

module.exports = constructorMethod;