const express = require('express');
const router = express.Router();
const data = require("../data");
const isPalindrome = data.isPalindrome;

router.get("/clientform", (req, res) => {
    res.render("isPalindrome/static", {});
});

router.get("/serverform", (req, res) => {
    res.render("isPalindrome/server", {});
});

router.post("/serverform", (req, res) => {
    let text_area = req.body.text_area;
    let result;
    try {
        result = isPalindrome.manipulate(text_area);
    } catch (e) {
        res.render("isPalindrome/server", {text_area: text_area, error: e });
        return;
    }

    res.render("isPalindrome/server", {text_area: text_area, result: result });
});

module.exports = router;