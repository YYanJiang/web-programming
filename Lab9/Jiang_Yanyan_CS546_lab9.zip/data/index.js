const palindromes = require("./palindromes");

module.exports = {
    palindromes: palindromes
};